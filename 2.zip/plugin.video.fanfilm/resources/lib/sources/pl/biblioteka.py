# -*- coding: utf-8 -*-

"""
    FanFilm Project
"""

import json
import re
from urllib.parse import urlencode, parse_qs

from ptw.libraries import cleantitle, control, source_utils, log_utils
from ptw.libraries.log_utils import log, fflog
from ptw.debug import log_exception, fflog_exc
from six import ensure_str, ensure_text


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["en", "de", "fr", "gr", "ko", "pl", "pt", "ru"]
        self.domains = []


    def movie(self, imdb, title, localtitle, aliases, year):
        # fflog(f'{imdb=} {title=} {localtitle=} {year=} {aliases=}')
        try:
            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            return urlencode({"imdb": imdb, "title": title, "localtitle": localtitle, "originalname": originalname, "year": year})
        except Exception:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        # fflog(f'{imdb=} {tvdb=} {tvshowtitle=} {localtvshowtitle=} {year=} {aliases=}')
        try:
            originalname = [a for a in aliases if "originalname" in a]
            originalname = originalname[0]["originalname"] if originalname else ""
            return urlencode({"imdb": imdb, "tvdb": tvdb, "tvshowtitle": tvshowtitle, "localtvshowtitle": localtvshowtitle, "originalname": originalname, "year": year, })
        except Exception:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        # fflog(f'{url=} {imdb=} {tvdb=} {title=} {premiered=} {season=} {episode=}')
        try:
            if url is None:
                return
            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, "") for i in url])
            url.update({"premiered": premiered, "season": season, "episode": episode})
            # fflog(f'{url=}')
            return urlencode(url)
        except Exception:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        #log_utils.log(f'[library/biblioteka.py] {url=!r}', 1)
        # fflog(f'{url=}')
        try:
            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, "") for i in data])
            # fflog(f'{data=}')

            content_type = "episode" if "tvshowtitle" in data else "movie"

            if data.get("year"):
                years = (data["year"], str(int(data["year"]) + 1), str(int(data["year"]) - 1),)  # tuple
            else:
                fflog(f'szukanie niemożliwe z powodu braku roku')
                return sources
                # years = ("","","",)  # nie wiem, co wstawić
                
            # fflog(f'{years=}')

            if content_type == "movie":

                title = cleantitle.get(data["title"])
                localtitle = cleantitle.get(data["localtitle"])
                originalname = cleantitle.get(data.get("originalname", ""))
                # fflog(f'{title=} {localtitle=} {originalname=}',1,1)

                # ids = [data["imdb"]]
                ids = [data.get("imdb")]  # niektóre filmy mają tylko tmdb
                if not ids:
                    ids = [data.get("tmdb")]
                    pass

                r = control.jsonrpc('{"jsonrpc": "2.0",'
                                     '"method": "VideoLibrary.GetMovies",'
                                     '"params": {"filter": {"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]},'
                                     '           "properties": ["uniqueid", "imdbnumber", "title", "originaltitle", "file"] },'
                                     '"id": 1}' % years)
                #fflog(f'{r=}',1,1)
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["movies"]
                #fflog(f'{r=}',1,1)
                r = [i
                     for i in r
                     if ((
                          str(i["imdbnumber"]) in ids
                          or str(i.get("uniqueid",{}).get("imdb")) in ids
                          or str(i.get("uniqueid",{}).get("tmdb")) in ids
                         )
                        or (
                            localtitle in [cleantitle.get(ensure_str(i["title"])), cleantitle.get(ensure_str(i["originaltitle"])), ]
                              or title in [cleantitle.get(ensure_str(i["title"])), cleantitle.get(ensure_str(i["originaltitle"])), ]
                            or originalname and originalname in [cleantitle.get(ensure_str(i["title"])), cleantitle.get(ensure_str(i["originaltitle"])), ]
                           )
                        ) 
                    ]
                #fflog(f'{r=}',1,1)
                # fflog(f'r={json.dumps(r, indent=2)}',1,1)
                # r = [i for i in r if not ensure_str(i["file"]).endswith(".strm")]  # nie uwzględnianie plików strm
                if r:
                    r = r[0]
                    r = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails",'
                                         '"params": {"properties": ["streamdetails", "file"], "movieid": %s },'
                                         '"id": 1}' % r["movieid"])
                    r = ensure_text(r, "utf-8", errors="ignore")
                    r = json.loads(r)["result"]["moviedetails"]
                    #fflog(f'{r=}',1,1)
                    # fflog(f'r={json.dumps(r, indent=2)}',1,1)

            elif content_type == "episode":

                title = data["tvshowtitle"]
                localtitle = data["localtvshowtitle"]
                originalname = data.get("originalname", "")
                # fflog(f'{title=} {localtitle=} {originalname=}')

                season, episode = data["season"], data["episode"]
                # fflog(f'{season=} {episode=}')

                r = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["uniqueid", "imdbnumber", "title", "originaltitle"]}, "id": 1}' % years)
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["tvshows"]
                # fflog(f'{r=}')
                r = [i
                    for i in r 
                    if (
                        title in (ensure_str(i["title"]))
                        or localtitle in (ensure_str(i["title"]))
                        or originalname and originalname in (ensure_str(i["originaltitle"]))
                       )
                    ]
                # fflog(f'{r=}')
                if r:
                    r = r[0]  # jest w bibliotece serial
                    # sprawdzamy, czy jest odcinek
                    r = control.jsonrpc(
                        '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (
                            str(season), str(episode), str(r["tvshowid"])))
                    r = ensure_text(r, "utf-8", errors="ignore")
                    r = json.loads(r)["result"]["episodes"]
                    # fflog(f'{r=}')
                    # fflog(f'r={json.dumps(r, indent=2)}',1,1)
                    # r = [i for i in r if not ensure_str(i["file"]).endswith(".strm")]  # nie uwzględnianie plików strm
                    if r:
                        r = r[0]

                        r = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodeDetails",'
                                            ' "params": {"properties": ["streamdetails", "file"],'
                                            ' "episodeid": %s }, "id": 1}' % r["episodeid"])
                        r = ensure_text(r, "utf-8", errors="ignore")
                        r = json.loads(r)["result"]["episodedetails"]
                        # fflog(f'{r=}')

            # fflog(f'{r=}',1,1)
            # fflog(f'r={json.dumps(r, indent=2)}',1,1)
            if r:
                url = ensure_str(r["file"])

                try:
                    qual = int(r["streamdetails"]["video"][0]["width"])
                except Exception:
                    qual = -1

                if qual >= 2160:
                    quality = "4K"
                elif 1920 <= qual < 2000:
                    quality = "1080p"
                elif 1280 <= qual < 1900:
                    quality = "720p"
                elif qual < 1280:
                    quality = "SD"

                info = []

                s = 0
                url2 = ""
                # odczyt pliku z dysku
                try:
                    f = control.openFile(url)
                    if not url.endswith(".strm"):
                        s = f.size()
                    else:
                        strm_text = f.read()
                        # fflog(f'{strm_text=}',1,1)
                        strm_text = re.split('\r\n|\r|\n', strm_text)
                        strm_text = [l.strip() for l in strm_text]
                        strm_text = list(filter(None, strm_text))
                        # strm_text = [l for l in strm_text if not l.startswith("#")]
                        if len(strm_text) > 1:  # trzeba inna metode zastosowac
                            # url2 = url
                            # strm_text = url
                            strm_text = ""
                            # for line in strm_text:
                                # if line.startswith("#"):
                                    # print('trzeba inna metode zastosowac')
                                    # break
                        else:
                            strm_text = "".join(strm_text)
                        if strm_text.startswith("plugin://plugin.video.fanfilm"):
                            fflog('zawartość tego pliku strm nie prowadzi do zewnętrznego serwisu  {url}',0,1)
                            fflog('brak źródeł do przekazania')
                            return sources
                            pass
                        url2 = strm_text
                        s = 0
                    f.close()
                    s = source_utils.convert_size(s) if s else 0
                    # info.append(s)  # dołączane jest na końcu kodu
                except Exception:
                    fflog_exc(1)
                    pass

                try:
                    c = r["streamdetails"]["video"][0]["codec"]
                    if c == "avc1":
                        c = "h264"
                    if c == "h265":
                        c = "hevc"
                    info.append(c)
                except Exception:
                    pass

                try:
                    ac = r["streamdetails"]["audio"][0]["codec"]
                    if ac == "eac3":
                        ac = "dd+"
                    if ac == "dca":
                        ac = "dts"
                    if ac == "dtshd_ma":
                        ac = "dts-hd ma"
                    info.append(ac)
                except Exception:
                    pass

                try:
                    ach = r["streamdetails"]["audio"][0]["channels"]
                    if ach == 1:
                        ach = "mono"
                    if ach == 2:
                        ach = "2.0"
                    if ach == 6:
                        ach = "5.1"
                    if ach == 7:
                        ach = "6.1"
                    if ach == 8:
                        ach = "7.1"
                    info.append(ach)
                except Exception:
                    pass

                info = " / ".join(info)
                info = f"[{info}]"
                # info = f'{s} | [ {info} ]'  # tu dołączany jest rozmiar pliku
                info += f' | {s}'
                info = info if info != "[] | 0" else ""

                size = s
                # fflog(f'{size=}',1,1)
                
                #lang = "en"  # tak było przed zmianami
                lang = source_utils.get_lang_by_type(url)[0]  # ja dodałem detekcję
                # lang = lang if lang else "en"

                filename = url.rpartition("/")[-1]
                filename = filename.rpartition("\\")[-1]

                host = ""
                if url2:
                    host = source_utils.top_domain(url2)
                    # fflog(f'{host=}')
                    # host = host.split('.')[0]  # wyrzucenie ostatniego człona domeny (np. ".pl", ".com")
                    # fflog(f'{host=}')

                sources.append({
                    "source": host,
                    "quality": quality,
                    "language": lang,
                    "url": url if not url2 else url2,
                    "info": info,
                    "size": size if size else "",
                    "local": True,  # w sumie nie wiem jakie to ma konsekwencje (trzeba prześledzić kod głównie w sources.py)
                    # "local": True if not url.endswith(".strm") else False,
                    "direct": True,
                    "debridonly": False,
                    "filename": filename,  # opcjonalnie
                    })
                # fflog(f'last source={json.dumps(sources[-1], indent=2)}',1,1)

            fflog(f'przekazano źródeł: {len(sources)}')
            return sources
        except Exception:
            # log_utils.log('lib_scraper_fail', 1)
            fflog_exc(1)
            return sources


    def resolve(self, url):
        # fflog(f'{url=}')
        return url
