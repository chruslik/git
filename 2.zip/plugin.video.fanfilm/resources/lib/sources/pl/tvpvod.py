# -*- coding: utf-8 -*-
"""
FanFilm - źródło: vod.tvp.pl
Copyright (C) 2025
Dystrybuowane na licencji GPL-3.0
"""
# from lib.ff import requests, cleantitle, source_utils
# import json, random, re
# from lib.ff.log_utils import fflog, fflog_exc
# from urllib.parse import urlencode

import json
import random
import re
import requests
from urllib.parse import urlencode
# from ptw.libraries import control
from ptw.libraries import cleantitle, source_utils
from ptw.debug import fflog_exc, fflog

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['pl']
        self.show_payable = False
        self.base_url = 'https://vod.tvp.pl'
        self.api_url = 'https://vod.tvp.pl/api/'
        self.search_url = 'products/vods/search/VOD'
        self.tvshow_search_url = 'products/vods/search/SERIAL'
        self.platform = 'BROWSER'
        self.UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'
        self.base_headers = {
            'User-Agent': self.UA,
            'Referer': self.base_url,
            'X-Redge-VOD': 'true',
            'API-DeviceInfo': 'HbbTV;2.0.1 (ETSI 1.4.1);Chrome +DRM Samsung;Chrome +DRM Samsung;HbbTV;2.0.3',
            'Accept': 'application/json, text/plain, */*'
        }
        self.session = requests.Session()

    def heaGen(self):
        try:
            headers = self.base_headers.copy()
            headers['API-CorrelationID'] = 'smarttv_' + self.code_gen(32)
            return headers
        except Exception:
            fflog_exc(1)
            return self.base_headers

    def paramsGen(self):
        return {'lang': 'PL', 'platform': self.platform}

    def code_gen(self, length):
        return ''.join(random.choice('0123456789abcdef') for _ in range(length))

    def search(self, query, item_type):
        try:
            params = self.paramsGen()
            params['keyword'] = cleantitle.geturl(query)
            endpoint = self.search_url if item_type == 'movie' else self.tvshow_search_url if item_type == 'tvshow' else None
            if not endpoint:
                # fflog(f"tvp_vod: Invalid item_type: {item_type}")
                return []

            full_url = f'{self.api_url}{endpoint}'
            # fflog(f"tvp_vod: Searching {item_type} with URL: {full_url} and params: {params}")

            response = self.session.get(full_url, headers=self.heaGen(), params=params)
            # fflog(f"tvp_vod: Response status: {response.status_code}")
            # fflog(f'{response.url=}',1)

            if response.status_code != 200:
                return []
            data = response.json()
            items = data.get('items', [])
            if not self.show_payable:
                items = [i for i in items if not i.get('payable')]
                pass
            fflog(f"tvp_vod: Found {len(items)} items")
            return items
        except Exception:
            fflog_exc(1)
            return []

    def get_video_playlist(self, product_id, video_type, tenant_uid=None):
        try:
            params = {'videoType': video_type, 'platform': self.platform}
            if tenant_uid:
                params['tenant'] = tenant_uid

            url = f'{self.api_url}products/{product_id}/videos/playlist'
            response = self.session.get(url, headers=self.heaGen(), params=params)
            response.raise_for_status()
            return response.json()
        except Exception:
            fflog_exc(1)
            return None

    def get_best_quality_stream(self, sources_list):
        try:
            if not sources_list:
                return None
            for key in ['totalBitrate', 'bitrate']:
                filtered = [s for s in sources_list if s.get(key, 0) > 0]
                if filtered:
                    return max(filtered, key=lambda x: x[key])
            return sources_list[0]
        except Exception:
            fflog_exc(1)
            return None

    def movie(self, imdb, title, localtitle, aliases, year):
    # def movie(self, imdb, title, localtitle, aliases, year, **kwargs):
        # premiered = kwargs.get("premiered", "")
        # premiered = "".join(re.findall(r"\d{4}", premiered))
        try:
            # fflog(f"tvp_vod: Searching for movie '{localtitle}' ({year})")
            results = []
            search_results = self.search(cleantitle.geturl(localtitle), 'movie')
            fflog(f'{len(search_results)=}')
            for item in search_results:
                if item.get('type') != 'VOD' or not item.get('id'):
                    # fflog(f"pomijam {item=}, bo {item.get('type')=} {item.get('id')=}")
                    continue
                normalized_item_title = cleantitle.normalize(item.get('title', '')).lower()
                normalized_search_title = cleantitle.normalize(localtitle).lower()
                if normalized_search_title in normalized_item_title and abs(item.get('year', 0) - int(year)) <= 1:
                    # fflog(f"item={json.dumps(item, indent=2)}")
                    tenant_uid = item.get('tenant', {}).get('uid', '') if isinstance(item.get('tenant'), dict) else ''
                    is_audiodescription = 'audiodeskrypcja' in item.get('title', '').lower()
                    info = 'Lektor' + (' - Audiodescription' if is_audiodescription else '')
                    info2 = ''
                    info2 = item.get('title') or ""
                    unsure = ''
                    if item.get('uhd'):
                        quality = '2160p'
                    elif item.get('hd'):
                        quality = '1080p'
                        unsure = "quality"
                    else:
                        quality = 'SD'
                    fflog(f'{quality=}')
                    quality = '1080p'
                    unsure = "quality"  # w tym serwisie jakość jest chyba adaptacyjna
                    results.append({
                        'source': '',
                        'quality': quality,
                        'language': 'pl',
                        'url': f"DRMCDA|{item['id']}|{tenant_uid}|MOVIE",
                        'info': info,
                        'info2': info2,
                        'direct': False,
                        'direct': True,
                        'debridonly': False,
                        'unsure': unsure,
                    })
                else:
                    # fflog(f"nie dopasowano, bo dla {item=} \n  {normalized_item_title=} \n{normalized_search_title=} \n{item.get('year')=} \n{year=}")
                    pass
            fflog(f"tvp_vod: Found {len(results)} movie sources")
            return results
        except Exception:
            fflog_exc(1)
            return []

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return (tvshowtitle, localtvshowtitle, aliases), year

    def episode(self, url, imdb, tvdb, title, premiered, season, episode, **kwargs):
        # fflog(f'{url=} {imdb=} {tvdb=} {title=} {premiered=} {season=} {episode=} {kwargs=}',1,1)
        tmdb = kwargs.get("tmdb")
        absolute_episode = kwargs.get("absolute_episode")
        try:
            show_info, year = url
            tvshowtitle, localtvshowtitle, aliases = show_info
            sources = []

            fflog(f"tvp_vod: Searching for show '{localtvshowtitle}' ({year})")
            search_results = self.search(cleantitle.geturl(localtvshowtitle), 'tvshow')
            if not search_results:
                fflog("tvp_vod: No search results found for tvshow")
                return []

            matched_show = None
            fflog(f'{len(search_results)=}')
            for item in search_results:
                if item.get('type') != 'SERIAL':
                    fflog(f"pomijam {item.get('title')=}, bo to nie serial")
                    continue

                # Dokładne dopasowanie tytułów
                normalized_item_title = cleantitle.normalize(item.get('title', '')).lower()
                normalized_search_title = cleantitle.normalize(localtvshowtitle).lower()

                title_match = normalized_item_title == normalized_search_title

                # Sprawdź rok - dla starych produkcji może być None
                year_match = True  # Domyślnie ignoruj rok
                item_year = item.get('year')
                if item_year is not None and year:
                    year_tolerance = 5 if int(year) < 1990 else 2
                    year_match = abs(int(item_year) - int(year)) <= year_tolerance

                if title_match and year_match:
                    matched_show = item
                    fflog(f"tvp_vod: Matched show '{item.get('title')}' (ID: {item.get('id')})")
                    break

                # fflog(f"nie dopasowano, bo dla {item=} \n  {normalized_item_title=} \n{normalized_search_title=} \n{item.get('year')=} \n{year=}")

            if not matched_show:
                fflog(f"tvp_vod: No matching show found for '{localtvshowtitle}'")
                return []

            show_id = matched_show['id']
            # Get seasons
            seasons_data = self.session.get(f'{self.api_url}products/vods/serials/{show_id}/seasons', headers=self.heaGen(), params=self.paramsGen())
            # fflog(f'{seasons_data.url=}')
            if not seasons_data:
                fflog(f'{seasons_data=}')
                return []
                pass
            seasons_data = seasons_data.json()

            found_episode = None

            # Spróbuj znaleźć odcinek bezpośrednio
            target_season = next((s for s in seasons_data if s.get('number') == int(season)), None)
            if target_season:
                season_id = target_season['id']
                episodes_data = self.session.get(f'{self.api_url}products/vods/serials/{show_id}/seasons/{season_id}/episodes',
                                               headers=self.heaGen(), params=self.paramsGen())
                # fflog(f'{episodes_data.url=}')
                if not seasons_data:
                    fflog(f'{episodes_data=}')
                    return []
                    pass
                episodes_data = episodes_data.json()
                episodes_data = sorted(episodes_data, key=lambda k: k['number'])
                target_index = int(episode) - 1
                if 0 <= target_index < len(episodes_data):
                    found_episode = episodes_data[target_index]
                    fflog(f"tvp_vod: Found episode directly: {found_episode.get('title')}")

            # Jeśli nie znaleziono, spróbuj numeracji absolutnej
            if not found_episode:
                fflog("tvp_vod: Direct match failed, trying absolute numbering")
                # fflog(f'{absolute_episode=}')
                if 0 and not absolute_episode:
                    try:
                        _, absolute_episode_number = source_utils.get_absolute_number_tmdb(tmdb, season, episode)
                        fflog(f'{absolute_episode_number=}')
                    except Exception:
                        absolute_episode_number = None
                else:
                    absolute_episode_number = absolute_episode

                if absolute_episode_number:
                    count = 0
                    for s in sorted(seasons_data, key=lambda s: s.get('number', 0)):
                        episodes = self.session.get(f'{self.api_url}products/vods/serials/{show_id}/seasons/{s["id"]}/episodes',
                                                  headers=self.heaGen(), params=self.paramsGen())
                        # fflog(f'{episodes.url=}')
                        if not seasons_data:
                            fflog(f'{episodes=}')
                            return []
                            pass
                        episodes = episodes.json()
                        if count + len(episodes) >= absolute_episode_number:
                            episodes = sorted(episodes, key=lambda k: k['number'])
                            idx = absolute_episode_number - count - 1
                            if 0 <= idx < len(episodes):
                                found_episode = episodes[idx]
                                fflog(f"tvp_vod: Found episode by absolute numbering: {found_episode.get('title')}")
                                break
                        count += len(episodes)

            if not found_episode:
                fflog("tvp_vod: Episode not found")
                return []

            # fflog(f"found_episode={json.dumps(found_episode, indent=2)}")

            if found_episode.get('payable') and not self.show_payable:
                return []

            tenant_uid = found_episode.get('tenant', {}).get('uid', '') if isinstance(found_episode.get('tenant'), dict) else ''

            is_audiodescription = 'audiodeskrypcja' in found_episode.get('title', '').lower()
            info = 'Lektor' + (' - Audiodescription' if is_audiodescription else '')

            info2 = found_episode.get('title') or ""
            tytul_serialu = found_episode.get('season', {}).get("serial", {}).get("title") or ""
            if tytul_serialu:
                info2 = f"{tytul_serialu}, {info2}"
                pass

            unsure = ''
            if found_episode.get('uhd'):
                quality = '2160p'
            elif found_episode.get('hd'):
                quality = '1080p'
                unsure = "quality"
            else:
                quality = 'SD'
            fflog(f'{quality=}')
            quality = '1080p'
            unsure = "quality"  # w tym serwisie jakość jest chyba adaptacyjna
            
            sources.append({
                'source': '',
                'quality': quality,
                'language': 'pl',
                'url': f"DRMCDA|{found_episode['id']}|{tenant_uid}|EPISODE",
                'info': info,
                'info2': info2,
                'direct': False,
                'direct': True,
                'debridonly': False,
                # 'unsure': "quality",
                'unsure': unsure,
            })
            fflog(f"tvp_vod: Returning {len(sources)} episode sources")
            return sources
        except Exception:
            fflog_exc(1)
            return []

    def sources(self, url, hostDict, hostprDict):
        # fflog(f'{url=}')
        fflog(f'Przekazano źródeł: {len(url)}')
        return url

    def resolve(self, url):
        try:
            if not url.startswith('DRMCDA|'):
                return url

            parts = url.split('|')

            _, product_id, tenant_uid, video_type = parts
            api_video_type = 'MOVIE' if video_type == 'EPISODE' else video_type
            playlist = self.get_video_playlist(product_id, api_video_type, tenant_uid)
            if not playlist or not isinstance(playlist, dict):
                return None

            if 'code' in playlist and playlist['code'] == 'ITEM_NOT_PAID':
                return None

            protocol = None
            stream_url = None

            if 'sources' in playlist:
                has_drm = 'drm' in playlist and 'WIDEVINE' in playlist['drm'] and playlist['drm']['WIDEVINE'].get('src')
                if has_drm and 'DASH' in playlist['sources'] and playlist['sources']['DASH']:
                    stream_url = playlist['sources']['DASH'][0]['src']
                    protocol = 'mpd'
                elif 'HLS' in playlist['sources'] and playlist['sources']['HLS']:
                    stream_url = playlist['sources']['HLS'][0]['src']
                    protocol = 'hls'
                elif 'DASH' in playlist['sources'] and playlist['sources']['DASH']:
                    stream_url = playlist['sources']['DASH'][0]['src']
                    protocol = 'mpd'

            if not stream_url:
                return None

            if stream_url.startswith('//'):
                stream_url = 'https:' + stream_url

            headers_str = f"User-Agent={self.UA}&Referer={self.base_url}"

            adaptive_data = {
                'protocol': protocol or 'mpd',
                'mimetype': 'application/dash+xml' if protocol == 'mpd' else 'application/x-mpegURL',
                'manifest': stream_url,
                'licence_type': playlist.get('drm', {}).get('WIDEVINE', {}).get('type', '') if 'drm' in playlist else '',
                'licence_url': playlist.get('drm', {}).get('WIDEVINE', {}).get('src', '') if 'drm' in playlist else '',
                'licence_header': '',
                'post_data': '',
                'response_data': '',
                'content_lookup': False,
                'is_playable': True,
                'stream_headers': headers_str,
                'manifest_headers': headers_str
            }

            # return stream_url  # stream bez wymaganych zabezpieczeń (może być odtwarzany także przez standardowy odtwarzacz Kodi, choć wtedy mogą być problemy w przewijaniem)
            # fflog(f"DRMCDA|repr(adaptive_data)={json.dumps(adaptive_data, indent=2)}")
            return f"DRMCDA|{repr(adaptive_data)}"
        except Exception:
            fflog_exc(1)
            return None